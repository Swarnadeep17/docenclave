// firebase-init.js: Initialize Firebase (compat syntax for simplicity)
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "docenclave.firebaseapp.com",
  databaseURL: "https://docenclave-d5a43-default-rtdb.firebaseio.com",
  projectId: "docenclave-d5a43",
  storageBucket: "docenclave-d5a43.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};
firebase.initializeApp(firebaseConfig);
