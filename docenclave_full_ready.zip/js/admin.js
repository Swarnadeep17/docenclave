// admin.js: admin dashboard data
requireAuth(user=>{
  if(!(user.role==='admin'||user.role==='superadmin')){
    window.location='index.html';return;
  }
  // stats
  firebase.database().ref('stats/overall').on('value',snap=>{
    $('#overallStats').textContent=JSON.stringify(snap.val()||{},null,2);
  });
  // users
  firebase.database().ref('users').on('value',snap=>{
    const ul=$('#userList'); ul.innerHTML='';
    snap.forEach(child=>{
      const li=document.createElement('li');
      const u=child.val(); li.textContent=`${u.email} — ${u.role}`;
      ul.appendChild(li);
    });
  });
  // promo codes
  const promoList=$('#promoList');
  const promoRef=firebase.database().ref('promoCodes');
  promoRef.on('value',snap=>{
    promoList.innerHTML='';
    snap.forEach(child=>{
      const code=child.key;
      const val=child.val();
      const li=document.createElement('li');
      li.textContent=`${code} (${val.targetRole}) — redeemed ${val.redeemedBy?Object.keys(val.redeemedBy).length:0}`;
      promoList.appendChild(li);
    });
  });
  // create promo
  $('#promoCreateForm').addEventListener('submit',e=>{
    e.preventDefault();
    const code=$('#newPromoCode').value.trim();
    const role=$('#promoRole').value;
    if(!code) return;
    promoRef.child(code).set({
      targetRole:role,
      createdBy:user.uid,
      createdAt:Date.now()
    });
    $('#newPromoCode').value='';
  });
});
