// account.js: show user info + redeem promo
requireAuth(user=>{
  $('#userEmail').textContent=user.email;
  $('#userRole').textContent=user.role;

  const form=$('#promoForm');
  form.addEventListener('submit',e=>{
    e.preventDefault();
    const code=$('#promoInput').value.trim();
    const codeRef=firebase.database().ref('promoCodes/'+code);
    codeRef.transaction(codeObj=>{
      if(codeObj && !codeObj.redeemedBy?.[user.uid]){
        if(!codeObj.redeemedBy) codeObj.redeemedBy={};
        codeObj.redeemedBy[user.uid]=Date.now();
        return codeObj;
      }
      return codeObj; // no change if invalid
    },(err,committed,snap)=>{
      if(err||!committed){$('#promoMessage').textContent='Invalid or already used.';return;}
      const role=snap.val().targetRole||'premium';
      firebase.database().ref('users/'+user.uid+'/role').set(role).then(()=>{
        $('#promoMessage').textContent='Upgraded to '+role+'!';
        $('#userRole').textContent=role;
      });
    });
  });
});
