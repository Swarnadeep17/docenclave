// utils.js: helper functions for DOM, auth, stats
function $(sel){return document.querySelector(sel);}
function formatNumber(n){return n.toLocaleString();}
function isoWeek(date){
  const t=new Date(date.getTime());
  t.setHours(0,0,0,0);
  t.setDate(t.getDate() + 3 - (t.getDay()+6)%7);
  const week1=new Date(t.getFullYear(),0,4);
  return 1+Math.round(((t-week1)/86400000 -3 + (week1.getDay()+6)%7)/7);
}
function incrementStat(statKey, delta=1){
  const db=firebase.database();
  const now=new Date();
  const y=now.getFullYear();
  const m=String(now.getMonth()+1).padStart(2,'0');
  const d=String(now.getDate()).padStart(2,'0');
  const w=isoWeek(now);
  const updates=[];
  const paths=[
    `stats/overall/${statKey}`,
    `stats/timeBased/daily/${y}-${m}-${d}/${statKey}`,
    `stats/timeBased/weekly/${y}-W${w}/${statKey}`,
    `stats/timeBased/monthly/${y}-${m}/${statKey}`
  ];
  paths.forEach(p=>updates.push(db.ref(p).transaction(val=>(val||0)+delta)));
  return Promise.all(updates);
}
function requireAuth(onAuthed){
  firebase.auth().onAuthStateChanged(u=>{
    if(!u){window.location='auth.html';return;}
    firebase.database().ref('users/'+u.uid).once('value').then(snap=>{
      const userObj=snap.val()||{};
      onAuthed({...userObj, uid:u.uid, email:u.email});
    });
  });
}
