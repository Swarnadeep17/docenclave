// auth.js: login / register
let mode='login';
const form=$('#authForm');
const toggle=$('#toggleLink');
const submitBtn=$('#authSubmit');
toggle.addEventListener('click',e=>{
  e.preventDefault();
  mode=mode==='login'?'register':'login';
  submitBtn.textContent=mode==='login'?'Login':'Register';
  $('#toggleMode').innerHTML=mode==='login'?'Need an account? <a href="#" id="toggleLink">Register</a>':'Have an account? <a href="#" id="toggleLink">Login</a>';
});
form.addEventListener('submit',e=>{
  e.preventDefault();
  const email=$('#email').value.trim();
  const pass=$('#password').value;
  const fn=mode==='login'?firebase.auth().signInWithEmailAndPassword:firebase.auth().createUserWithEmailAndPassword;
  fn.call(firebase.auth(),email,pass)
  .then(cred=>{
    if(mode==='register'){
      firebase.database().ref('users/'+cred.user.uid).set({email,role:'free',createdAt:Date.now()});
    }
    window.location='index.html';
  })
  .catch(err=>$('#authError').textContent=err.message);
});
