// index.js: homepage logic
incrementStat('visits',1);

firebase.database().ref('stats/overall').on('value',snap=>{
  const data=snap.val()||{};
  $('#totalVisits').textContent=formatNumber(data.visits||0);
  $('#totalDownloads').textContent=formatNumber(data.downloads||0);
});

// Auth nav link toggle
firebase.auth().onAuthStateChanged(u=>{
  if(u){
    $('#loginLink').style.display='none';
    $('#accountLink').style.display='';
    firebase.database().ref('users/'+u.uid+'/role').once('value').then(s=>{
      const role=s.val();
      if(role==='admin'||role==='superadmin'){ $('#adminLink').style.display=''; }
    });
  }
});
