# Docenclave — Vanilla JS Edition

A framework‑free rebuild of Docenclave using plain HTML, CSS and JavaScript with Firebase.

## Quick start

1. Upload all files in this repo to **main** branch of `Swarnadeep17/docenclave`.
2. In **js/firebase-init.js** paste your real Firebase project credentials.
3. Make sure you’ve linked the repo to Firebase Hosting (see below) or set the GitHub secret **FIREBASE_SERVICE_ACCOUNT**.

## Deployment

A GitHub Actions workflow (`.github/workflows/firebase-hosting.yml`) automatically
deploys to Firebase Hosting on each push to **main**.

## Structure

| Path | Purpose |
|------|---------|
| `index.html` | Homepage with live counters |
| `auth.html` | Login / Register |
| `account.html` | Account & promo code |
| `admin.html` | Admin dashboard |
| `css/` | Styles |
| `js/` | Firebase init & page scripts |
| `firebase.json` | Hosting config |
| `database.rules.json` | Realtime DB rules |

Enjoy!